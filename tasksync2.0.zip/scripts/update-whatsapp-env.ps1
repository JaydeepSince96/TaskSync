# Update WhatsApp environment variable in Elastic Beanstalk
param(
    [string]$EnvironmentName = "tasksync-api-env",
    [string]$Region = "ap-south-1"
)

Write-Host "🔧 Updating WhatsApp environment variable in Elastic Beanstalk..." -ForegroundColor Green

# Set the correct WhatsApp number format
$whatsappNumber = "whatsapp:+17817227094"

Write-Host "📱 Setting TWILIO_WHATSAPP_NUMBER to: $whatsappNumber" -ForegroundColor Yellow

# Create the option settings JSON
$optionSettingsJson = @"
[
    {
        "Namespace": "aws:elasticbeanstalk:application:environment",
        "OptionName": "TWILIO_WHATSAPP_NUMBER",
        "Value": "$whatsappNumber"
    }
]
"@

Write-Host "🚀 Updating environment variables..." -ForegroundColor Yellow

try {
    # Update the environment
    aws elasticbeanstalk update-environment `
        --environment-name $EnvironmentName `
        --region $Region `
        --option-settings $optionSettingsJson

    Write-Host "✅ Environment update initiated successfully!" -ForegroundColor Green
    Write-Host "⏳ The update will take a few minutes to complete." -ForegroundColor Yellow
    Write-Host "🔄 Your application will restart automatically." -ForegroundColor Yellow
    
    Write-Host "`n📋 To check the status, run:" -ForegroundColor Cyan
    Write-Host "aws elasticbeanstalk describe-environments --environment-names $EnvironmentName --region $Region" -ForegroundColor White
    
} catch {
    Write-Host "❌ Error updating environment: $_" -ForegroundColor Red
    Write-Host "`n💡 Manual Steps:" -ForegroundColor Yellow
    Write-Host "1. Go to AWS Elastic Beanstalk Console" -ForegroundColor White
    Write-Host "2. Select your environment: $EnvironmentName" -ForegroundColor White
    Write-Host "3. Go to Configuration → Software" -ForegroundColor White
    Write-Host "4. Find TWILIO_WHATSAPP_NUMBER" -ForegroundColor White
    Write-Host "5. Change value to: $whatsappNumber" -ForegroundColor White
    Write-Host "6. Click 'Apply' and wait for restart" -ForegroundColor White
}

Write-Host "`n🎯 After the update completes:" -ForegroundColor Green
Write-Host "1. Wait for the environment to finish updating" -ForegroundColor White
Write-Host "2. Test the WhatsApp connection again" -ForegroundColor White
Write-Host "3. The error should be resolved" -ForegroundColor White 