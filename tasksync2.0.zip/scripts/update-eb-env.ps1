# PowerShell script to update Elastic Beanstalk environment variables for AWS SES
# Run this script after creating new AWS SES credentials

param(
    [Parameter(Mandatory=$true)]
    [string]$EnvironmentName,
    
    [Parameter(Mandatory=$true)]
    [string]$AccessKeyId,
    
    [Parameter(Mandatory=$true)]
    [string]$SecretAccessKey,
    
    [Parameter(Mandatory=$true)]
    [string]$FromEmail,
    
    [string]$Region = "ap-south-1"
)

Write-Host "🔧 Updating Elastic Beanstalk environment variables for AWS SES..." -ForegroundColor Yellow

# Set AWS region
$env:AWS_DEFAULT_REGION = $Region

# Update environment variables
$optionSettings = @(
    @{
        Namespace = "aws:elasticbeanstalk:application:environment"
        OptionName = "AWS_SES_ACCESS_KEY_ID"
        Value = $AccessKeyId
    },
    @{
        Namespace = "aws:elasticbeanstalk:application:environment"
        OptionName = "AWS_SES_SECRET_ACCESS_KEY"
        Value = $SecretAccessKey
    },
    @{
        Namespace = "aws:elasticbeanstalk:application:environment"
        OptionName = "AWS_SES_REGION"
        Value = $Region
    },
    @{
        Namespace = "aws:elasticbeanstalk:application:environment"
        OptionName = "AWS_SES_FROM_EMAIL"
        Value = $FromEmail
    }
)

# Convert to JSON
$optionSettingsJson = $optionSettings | ConvertTo-Json -Depth 3

# Update the environment
Write-Host "📝 Updating environment: $EnvironmentName" -ForegroundColor Cyan
aws elasticbeanstalk update-environment `
    --environment-name $EnvironmentName `
    --option-settings $optionSettingsJson

if ($LASTEXITCODE -eq 0) {
    Write-Host "✅ Environment variables updated successfully!" -ForegroundColor Green
    Write-Host "🔄 Your application will restart automatically..." -ForegroundColor Yellow
    Write-Host "⏳ Wait 2-3 minutes for the deployment to complete" -ForegroundColor Yellow
} else {
    Write-Host "❌ Failed to update environment variables" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "📋 Next Steps:" -ForegroundColor Cyan
Write-Host "1. Wait for deployment to complete (2-3 minutes)" -ForegroundColor White
Write-Host "2. Test email functionality" -ForegroundColor White
Write-Host "3. Check logs for successful email service initialization" -ForegroundColor White
Write-Host ""
Write-Host "🧪 Test Command:" -ForegroundColor Cyan
Write-Host "curl -X POST https://your-app.elasticbeanstalk.com/api/notifications/email/test -H 'Content-Type: application/json' -d '{\"email\": \"test@example.com\"}'" -ForegroundColor Gray 