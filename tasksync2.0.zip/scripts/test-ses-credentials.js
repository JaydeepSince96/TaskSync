// Test AWS SES credentials directly
const nodemailer = require('nodemailer');

// Your AWS SES credentials (replace with your actual values)
const AWS_SES_ACCESS_KEY_ID = 'AKIAYS5S2ESON7L3N2UH';
const AWS_SES_SECRET_ACCESS_KEY = '/1mNlCxuW3IGbGRPR9Z5FfjJaPeWkpFotVOOaVA6';
const AWS_SES_REGION = 'ap-south-1';
const AWS_SES_FROM_EMAIL = 'noreply@tasksync.org';

console.log('🔍 Testing AWS SES Credentials');
console.log('==============================');

console.log('\n📋 Credentials Check:');
console.log(`Access Key ID: ${AWS_SES_ACCESS_KEY_ID ? '✅ Set' : '❌ Missing'}`);
console.log(`Secret Access Key: ${AWS_SES_SECRET_ACCESS_KEY ? '✅ Set' : '❌ Missing'}`);
console.log(`Region: ${AWS_SES_REGION}`);
console.log(`From Email: ${AWS_SES_FROM_EMAIL}`);

// Check if secret key looks complete
if (AWS_SES_SECRET_ACCESS_KEY && AWS_SES_SECRET_ACCESS_KEY.length < 30) {
    console.log('\n⚠️  WARNING: Your Secret Access Key appears to be incomplete!');
    console.log(`Current length: ${AWS_SES_SECRET_ACCESS_KEY.length} characters`);
    console.log('AWS SES secret keys should be around 40 characters long');
    console.log('Please check your AWS IAM Console for the complete key');
}

// Create transporter
console.log('\n🔧 Creating AWS SES transporter...');
const transporter = nodemailer.createTransporter({
    host: `email-smtp.${AWS_SES_REGION}.amazonaws.com`,
    port: 587,
    secure: false,
    auth: {
        user: AWS_SES_ACCESS_KEY_ID,
        pass: AWS_SES_SECRET_ACCESS_KEY,
    },
});

// Test connection
console.log('\n🧪 Testing AWS SES connection...');
transporter.verify((error, success) => {
    if (error) {
        console.log('❌ Connection failed:', error.message);
        console.log('\n🔍 Troubleshooting tips:');
        console.log('1. Check if your AWS credentials are correct');
        console.log('2. Verify your email address in AWS SES Console');
        console.log('3. Ensure your IAM user has SES permissions');
        console.log('4. Check if you\'re in the correct AWS region');
        console.log('\n📋 Common issues:');
        console.log('- Invalid access key or secret key');
        console.log('- Email not verified in SES');
        console.log('- Insufficient IAM permissions');
        console.log('- Wrong AWS region');
        console.log('- Secret key is incomplete');
    } else {
        console.log('✅ Connection successful!');
        console.log('📧 AWS SES is properly configured');
        
        // Test sending email
        console.log('\n📤 Testing email sending...');
        const testEmail = {
            from: AWS_SES_FROM_EMAIL,
            to: 'test@example.com',
            subject: 'AWS SES Test Email',
            text: 'This is a test email from AWS SES',
            html: '<h1>Test Email</h1><p>This is a test email from AWS SES</p>'
        };
        
        transporter.sendMail(testEmail, (error, info) => {
            if (error) {
                console.log('❌ Email sending failed:', error.message);
                console.log('\n🔍 Possible causes:');
                console.log('- Email address not verified in SES');
                console.log('- Account still in sandbox mode');
                console.log('- Invalid sender email');
                console.log('- Domain not verified');
            } else {
                console.log('✅ Email sent successfully!');
                console.log('Message ID:', info.messageId);
                console.log('\n🎉 AWS SES is working correctly!');
            }
        });
    }
}); 