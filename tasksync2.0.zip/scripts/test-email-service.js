#!/usr/bin/env node

/**
 * Email Service Test Script
 * 
 * This script helps diagnose email service issues and test configurations
 * Run with: node scripts/test-email-service.js
 */

// Test script to verify AWS SES configuration
const nodemailer = require('nodemailer');
require('dotenv').config();

// Fix for nodemailer import
const { createTransport } = nodemailer;

// Get environment variables
const AWS_SES_ACCESS_KEY_ID = process.env.AWS_SES_ACCESS_KEY_ID;
const AWS_SES_SECRET_ACCESS_KEY = process.env.AWS_SES_SECRET_ACCESS_KEY;
const AWS_SES_REGION = process.env.AWS_SES_REGION || 'ap-south-1';
const AWS_SES_FROM_EMAIL = process.env.AWS_SES_FROM_EMAIL;

console.log('🔍 AWS SES Configuration Test');
console.log('=============================');

// Check if environment variables are set
console.log('\n📋 Environment Variables:');
console.log(`AWS_SES_ACCESS_KEY_ID: ${AWS_SES_ACCESS_KEY_ID ? '✅ Set' : '❌ Missing'}`);
console.log(`AWS_SES_SECRET_ACCESS_KEY: ${AWS_SES_SECRET_ACCESS_KEY ? '✅ Set' : '❌ Missing'}`);
console.log(`AWS_SES_REGION: ${AWS_SES_REGION}`);
console.log(`AWS_SES_FROM_EMAIL: ${AWS_SES_FROM_EMAIL || '❌ Missing'}`);

if (!AWS_SES_ACCESS_KEY_ID || !AWS_SES_SECRET_ACCESS_KEY || !AWS_SES_FROM_EMAIL) {
    console.log('\n❌ Missing required environment variables!');
    console.log('Please set the following environment variables:');
    console.log('- AWS_SES_ACCESS_KEY_ID');
    console.log('- AWS_SES_SECRET_ACCESS_KEY');
    console.log('- AWS_SES_FROM_EMAIL');
    process.exit(1);
}

// Create transporter
console.log('\n🔧 Creating AWS SES transporter...');
const transporter = createTransport({
    host: `email-smtp.${AWS_SES_REGION}.amazonaws.com`,
    port: 587,
    secure: false,
    auth: {
        user: AWS_SES_ACCESS_KEY_ID,
        pass: AWS_SES_SECRET_ACCESS_KEY,
    },
});

// Test connection
console.log('\n🧪 Testing AWS SES connection...');
transporter.verify((error, success) => {
    if (error) {
        console.log('❌ Connection failed:', error.message);
        console.log('\n🔍 Troubleshooting tips:');
        console.log('1. Check if your AWS credentials are correct');
        console.log('2. Verify your email address in AWS SES Console');
        console.log('3. Ensure your IAM user has SES permissions');
        console.log('4. Check if you\'re in the correct AWS region');
        console.log('\n📋 Common issues:');
        console.log('- Invalid access key or secret key');
        console.log('- Email not verified in SES');
        console.log('- Insufficient IAM permissions');
        console.log('- Wrong AWS region');
    } else {
        console.log('✅ Connection successful!');
        console.log('📧 AWS SES is properly configured');
        
        // Test sending email
        console.log('\n📤 Testing email sending...');
        const testEmail = {
            from: AWS_SES_FROM_EMAIL,
            to: 'test@example.com',
            subject: 'AWS SES Test Email',
            text: 'This is a test email from AWS SES',
            html: '<h1>Test Email</h1><p>This is a test email from AWS SES</p>'
        };
        
        transporter.sendMail(testEmail, (error, info) => {
            if (error) {
                console.log('❌ Email sending failed:', error.message);
                console.log('\n🔍 Possible causes:');
                console.log('- Email address not verified in SES');
                console.log('- Account still in sandbox mode');
                console.log('- Invalid sender email');
            } else {
                console.log('✅ Email sent successfully!');
                console.log('Message ID:', info.messageId);
                console.log('\n🎉 AWS SES is working correctly!');
            }
        });
    }
}); 