// Debug WhatsApp production issue
require('dotenv').config();

console.log('🔍 Debugging WhatsApp Production Issue...\n');

// Check all environment variables
console.log('📋 Environment Variables Check:');
console.log('  NODE_ENV:', process.env.NODE_ENV);
console.log('  TWILIO_ACCOUNT_SID:', process.env.TWILIO_ACCOUNT_SID ? `${process.env.TWILIO_ACCOUNT_SID.substring(0, 15)}...` : '❌ Not set');
console.log('  TWILIO_AUTH_TOKEN:', process.env.TWILIO_AUTH_TOKEN ? `${process.env.TWILIO_AUTH_TOKEN.substring(0, 15)}...` : '❌ Not set');
console.log('  TWILIO_WHATSAPP_NUMBER:', process.env.TWILIO_WHATSAPP_NUMBER || '❌ Not set');

console.log('\n🔧 Testing WhatsApp Service Initialization...');

try {
  // Import and test the WhatsApp service
  const { WhatsAppService } = require('../dist/services/whatsapp-service');
  
  console.log('✅ WhatsAppService imported successfully');
  
  const whatsappService = new WhatsAppService();
  console.log('✅ WhatsAppService instance created');
  
  const status = whatsappService.getStatus();
  console.log('📱 Service Status:', JSON.stringify(status, null, 2));
  
  if (!status.available) {
    console.log('❌ WhatsApp service is not available');
    console.log('  - Initialized:', status.initialized);
    console.log('  - Has Credentials:', status.hasCredentials);
    console.log('  - From Number:', status.fromNumber);
    
    if (!status.hasCredentials) {
      console.log('\n🚨 Issue: Missing Twilio credentials');
      console.log('   Make sure TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN are set');
    }
    
    if (!status.initialized) {
      console.log('\n🚨 Issue: Service not initialized');
      console.log('   Check if Twilio client creation failed');
    }
  } else {
    console.log('✅ WhatsApp service is available');
    
    // Test with a dummy phone number to see the exact error
    console.log('\n🧪 Testing with dummy phone number...');
    const testResult = await whatsappService.testConnection('+1234567890');
    console.log('Test result:', testResult);
  }
  
} catch (error) {
  console.error('❌ Error during WhatsApp service test:', error);
  console.error('Error details:', {
    message: error.message,
    stack: error.stack,
    code: error.code
  });
}

console.log('\n🎯 Next Steps:');
console.log('1. Check the server logs for detailed error messages');
console.log('2. Verify all environment variables are set correctly');
console.log('3. Test with a real phone number in international format'); 