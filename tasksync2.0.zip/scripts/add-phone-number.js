#!/usr/bin/env node

/**
 * Add Phone Number Script
 * 
 * This script helps you add your phone number to your user profile
 * Run with: node scripts/add-phone-number.js
 */

require('dotenv').config();
const mongoose = require('mongoose');
const { User } = require('../dist/models/user-model');

console.log('📱 Add Phone Number to User Profile');
console.log('===================================');

// Get command line arguments
const email = process.argv[2];
const phoneNumber = process.argv[3];

if (!email || !phoneNumber) {
    console.log('\n❌ Please provide email and phone number');
    console.log('Usage: node scripts/add-phone-number.js your-email@example.com +1234567890');
    console.log('\n📋 Example:');
    console.log('node scripts/add-phone-number.js john@example.com +1234567890');
    process.exit(1);
}

// Validate phone number format
if (!phoneNumber.startsWith('+')) {
    console.log('\n❌ Phone number must start with + (international format)');
    console.log('Example: +1234567890');
    process.exit(1);
}

async function addPhoneNumber() {
    try {
        // Connect to database
        await mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/TaskSync');
        console.log('✅ Connected to database');

        // Find user by email
        const user = await User.findOne({ email: email.toLowerCase() });
        
        if (!user) {
            console.log(`❌ User with email ${email} not found`);
            process.exit(1);
        }

        console.log(`✅ Found user: ${user.name} (${user.email})`);
        console.log(`📱 Current phone number: ${user.phoneNumber || 'Not set'}`);

        // Update phone number
        user.phoneNumber = phoneNumber;
        await user.save();

        console.log(`✅ Phone number updated successfully!`);
        console.log(`📱 New phone number: ${user.phoneNumber}`);
        
        console.log('\n🎉 You can now receive WhatsApp notifications!');
        console.log('\n📋 What happens next:');
        console.log('1. Daily reminders at 10am, 3pm, and 7pm');
        console.log('2. Task deadline notifications');
        console.log('3. Task status updates');
        
        console.log('\n🧪 To test:');
        console.log('1. Start your application: npm start');
        console.log('2. Create a task with today\'s date');
        console.log('3. You should receive WhatsApp notifications');

    } catch (error) {
        console.error('❌ Error:', error.message);
    } finally {
        await mongoose.disconnect();
        console.log('✅ Disconnected from database');
    }
}

addPhoneNumber(); 