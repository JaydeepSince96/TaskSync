// Test WhatsApp configuration
require('dotenv').config();

console.log('🔍 Testing WhatsApp Configuration...\n');

// Check environment variables
const requiredVars = [
  'TWILIO_ACCOUNT_SID',
  'TWILIO_AUTH_TOKEN', 
  'TWILIO_WHATSAPP_NUMBER'
];

console.log('📋 Environment Variables:');
requiredVars.forEach(varName => {
  const value = process.env[varName];
  const status = value ? '✅ Set' : '❌ Missing';
  const displayValue = value ? `${value.substring(0, 10)}...` : 'Not set';
  console.log(`  ${varName}: ${status} (${displayValue})`);
});

console.log('\n🔧 Testing Twilio Client...');

try {
  const twilio = require('twilio');
  
  if (!process.env.TWILIO_ACCOUNT_SID || !process.env.TWILIO_AUTH_TOKEN) {
    console.log('❌ Missing Twilio credentials. Please set TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN');
    process.exit(1);
  }

  const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
  console.log('✅ Twilio client created successfully');

  // Test account info
  client.api.accounts(process.env.TWILIO_ACCOUNT_SID)
    .fetch()
    .then(account => {
      console.log('✅ Twilio account verified:');
      console.log(`  Account Name: ${account.friendlyName}`);
      console.log(`  Status: ${account.status}`);
      console.log(`  Type: ${account.type}`);
    })
    .catch(error => {
      console.log('❌ Failed to verify Twilio account:', error.message);
    });

} catch (error) {
  console.log('❌ Error creating Twilio client:', error.message);
}

console.log('\n📱 WhatsApp Number Configuration:');
if (process.env.TWILIO_WHATSAPP_NUMBER) {
  console.log(`  From Number: ${process.env.TWILIO_WHATSAPP_NUMBER}`);
} else {
  console.log('  ❌ TWILIO_WHATSAPP_NUMBER not set');
  console.log('  💡 Default will be used: whatsapp:+14155238886 (Twilio Sandbox)');
}

console.log('\n🎯 Next Steps:');
console.log('1. Make sure all environment variables are set');
console.log('2. If using Twilio Sandbox, join the sandbox first');
console.log('3. Test with a real phone number in international format (+1234567890)'); 