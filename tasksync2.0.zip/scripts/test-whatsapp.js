#!/usr/bin/env node

/**
 * Test WhatsApp Notification System
 * 
 * This script tests the WhatsApp notification functionality
 * Run with: node scripts/test-whatsapp.js
 */

require('dotenv').config();

const { WhatsAppService } = require('../dist/services/whatsapp-service');
const { NotificationScheduler } = require('../dist/services/notification-scheduler');

console.log('📱 Testing WhatsApp Notification System');
console.log('=======================================');

// Check environment variables
console.log('\n📋 Environment Variables:');
console.log(`TWILIO_ACCOUNT_SID: ${process.env.TWILIO_ACCOUNT_SID ? '✅ Set' : '❌ Missing'}`);
console.log(`TWILIO_AUTH_TOKEN: ${process.env.TWILIO_AUTH_TOKEN ? '✅ Set' : '❌ Missing'}`);
console.log(`TWILIO_WHATSAPP_NUMBER: ${process.env.TWILIO_WHATSAPP_NUMBER || '❌ Missing'}`);

if (!process.env.TWILIO_ACCOUNT_SID || !process.env.TWILIO_AUTH_TOKEN) {
    console.log('\n❌ Missing required Twilio credentials!');
    console.log('Please set the following environment variables:');
    console.log('- TWILIO_ACCOUNT_SID');
    console.log('- TWILIO_AUTH_TOKEN');
    console.log('- TWILIO_WHATSAPP_NUMBER (optional, will use sandbox)');
    process.exit(1);
}

// Test WhatsApp service
async function testWhatsAppService() {
    console.log('\n🧪 Testing WhatsApp Service...');
    
    const whatsappService = new WhatsAppService();
    
    // Check service status
    const status = whatsappService.getStatus();
    console.log('📊 Service Status:', status);
    
    if (!status.available) {
        console.log('❌ WhatsApp service is not available');
        return false;
    }
    
    // Get test phone number from command line
    const testPhoneNumber = process.argv[2];
    
    if (!testPhoneNumber) {
        console.log('\n❌ Please provide a test phone number');
        console.log('Usage: node scripts/test-whatsapp.js +1234567890');
        console.log('\n📋 Note: For Twilio sandbox, you need to join the sandbox first');
        console.log('Send "join <sandbox-code>" to the Twilio WhatsApp number');
        return false;
    }
    
    // Test connection
    console.log(`\n📤 Testing WhatsApp connection to ${testPhoneNumber}...`);
    const connectionResult = await whatsappService.testConnection(testPhoneNumber);
    
    if (connectionResult) {
        console.log('✅ WhatsApp connection test successful!');
        return true;
    } else {
        console.log('❌ WhatsApp connection test failed');
        return false;
    }
}

// Test notification scheduler
async function testNotificationScheduler() {
    console.log('\n⏰ Testing Notification Scheduler...');
    
    const scheduler = new NotificationScheduler();
    
    // Get scheduler status
    const status = scheduler.getStatus();
    console.log('📊 Scheduler Status:', status);
    
    console.log('✅ Notification scheduler initialized');
    console.log('📅 Daily reminders scheduled for: 10am, 3pm, 7pm');
    console.log('🔍 Deadline checks scheduled every hour');
    
    return true;
}

// Test notification types
async function testNotificationTypes() {
    console.log('\n📨 Testing Notification Types...');
    
    const whatsappService = new WhatsAppService();
    const testPhoneNumber = process.argv[2];
    
    if (!testPhoneNumber) {
        console.log('⚠️ Skipping notification type tests (no phone number provided)');
        return;
    }
    
    // Test data
    const mockTask = {
        _id: 'test-task-id',
        title: 'Test Task',
        description: 'This is a test task for WhatsApp notifications',
        completed: false,
        label: 'high priority',
        startDate: new Date(),
        dueDate: new Date(),
        userId: 'test-user-id',
        assignedTo: []
    };
    
    const mockUser = {
        _id: 'test-user-id',
        name: 'Test User',
        email: 'test@example.com',
        phoneNumber: testPhoneNumber
    };
    
    // Test deadline notification
    console.log('\n📅 Testing Deadline Notification...');
    try {
        const deadlineResult = await whatsappService.sendTaskDeadlineNotification({
            task: mockTask,
            user: mockUser,
            isDeadline: true
        });
        console.log(deadlineResult ? '✅ Deadline notification sent' : '❌ Deadline notification failed');
    } catch (error) {
        console.log('❌ Error sending deadline notification:', error.message);
    }
    
    // Test daily reminder
    console.log('\n🌅 Testing Daily Reminder...');
    try {
        const dailyResult = await whatsappService.sendDailyReminder({
            user: mockUser,
            tasks: [mockTask],
            reminderTime: '10am'
        });
        console.log(dailyResult ? '✅ Daily reminder sent' : '❌ Daily reminder failed');
    } catch (error) {
        console.log('❌ Error sending daily reminder:', error.message);
    }
    
    // Test custom message
    console.log('\n💬 Testing Custom Message...');
    try {
        const customResult = await whatsappService.sendCustomMessage(
            testPhoneNumber,
            '🧪 This is a test custom message from TaskSync WhatsApp service!'
        );
        console.log(customResult ? '✅ Custom message sent' : '❌ Custom message failed');
    } catch (error) {
        console.log('❌ Error sending custom message:', error.message);
    }
}

// Main test function
async function runTests() {
    try {
        console.log('🚀 Starting WhatsApp notification tests...\n');
        
        // Test WhatsApp service
        const whatsappResult = await testWhatsAppService();
        
        // Test notification scheduler
        const schedulerResult = await testNotificationScheduler();
        
        // Test notification types (if WhatsApp is working)
        if (whatsappResult) {
            await testNotificationTypes();
        }
        
        console.log('\n📋 Test Summary:');
        console.log(`WhatsApp Service: ${whatsappResult ? '✅ Working' : '❌ Failed'}`);
        console.log(`Notification Scheduler: ${schedulerResult ? '✅ Working' : '❌ Failed'}`);
        
        if (whatsappResult && schedulerResult) {
            console.log('\n🎉 All tests passed! WhatsApp notifications are ready to use!');
            console.log('\n📱 Features Available:');
            console.log('- ✅ Task deadline notifications');
            console.log('- ✅ Daily reminders (10am, 3pm, 7pm)');
            console.log('- ✅ Custom messages');
            console.log('- ✅ Weekly reports');
        } else {
            console.log('\n⚠️ Some tests failed. Please check your configuration.');
        }
        
    } catch (error) {
        console.error('❌ Test error:', error);
    }
}

// Run tests
runTests(); 