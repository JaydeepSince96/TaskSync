#!/usr/bin/env node

/**
 * Test Email Sending in Sandbox Mode
 * 
 * This script tests email sending with verified recipient emails
 * Run with: node scripts/test-sandbox-email.js
 */

const nodemailer = require('nodemailer');
require('dotenv').config();

const { createTransport } = nodemailer;

// Get environment variables
const AWS_SES_ACCESS_KEY_ID = process.env.AWS_SES_ACCESS_KEY_ID;
const AWS_SES_SECRET_ACCESS_KEY = process.env.AWS_SES_SECRET_ACCESS_KEY;
const AWS_SES_REGION = process.env.AWS_SES_REGION || 'ap-south-1';
const AWS_SES_FROM_EMAIL = process.env.AWS_SES_FROM_EMAIL;

console.log('🧪 Testing AWS SES in Sandbox Mode');
console.log('==================================');

// Check if environment variables are set
console.log('\n📋 Environment Variables:');
console.log(`AWS_SES_ACCESS_KEY_ID: ${AWS_SES_ACCESS_KEY_ID ? '✅ Set' : '❌ Missing'}`);
console.log(`AWS_SES_SECRET_ACCESS_KEY: ${AWS_SES_SECRET_ACCESS_KEY ? '✅ Set' : '❌ Missing'}`);
console.log(`AWS_SES_REGION: ${AWS_SES_REGION}`);
console.log(`AWS_SES_FROM_EMAIL: ${AWS_SES_FROM_EMAIL || '❌ Missing'}`);

if (!AWS_SES_ACCESS_KEY_ID || !AWS_SES_SECRET_ACCESS_KEY || !AWS_SES_FROM_EMAIL) {
    console.log('\n❌ Missing required environment variables!');
    process.exit(1);
}

// Create transporter
console.log('\n🔧 Creating AWS SES transporter...');
const transporter = createTransport({
    host: `email-smtp.${AWS_SES_REGION}.amazonaws.com`,
    port: 587,
    secure: false,
    auth: {
        user: AWS_SES_ACCESS_KEY_ID,
        pass: AWS_SES_SECRET_ACCESS_KEY,
    },
});

// Test connection
console.log('\n🧪 Testing AWS SES connection...');
transporter.verify((error, success) => {
    if (error) {
        console.log('❌ Connection failed:', error.message);
        process.exit(1);
    } else {
        console.log('✅ Connection successful!');
        console.log('📧 AWS SES is properly configured');
        
        // Get recipient email from command line argument
        const recipientEmail = process.argv[2];
        
        if (!recipientEmail) {
            console.log('\n❌ Please provide a verified recipient email address');
            console.log('Usage: node scripts/test-sandbox-email.js verified@email.com');
            console.log('\n📋 Important: In sandbox mode, you can ONLY send to verified email addresses');
            console.log('To verify an email:');
            console.log('1. Go to AWS SES Console → Verified identities');
            console.log('2. Click "Create identity" → "Email address"');
            console.log('3. Add the email address and verify it');
            process.exit(1);
        }
        
        // Test sending email to verified recipient
        console.log(`\n📤 Testing email sending to: ${recipientEmail}`);
        console.log('⚠️  Make sure this email is verified in AWS SES Console!');
        
        const testEmail = {
            from: AWS_SES_FROM_EMAIL,
            to: recipientEmail,
            subject: 'TaskSync Invitation Test - Sandbox Mode',
            text: `Hello!

This is a test invitation email from TaskSync.

Your account is currently in sandbox mode, which means:
- You can only send emails to verified addresses
- Production access request is under review (24 hours)
- Once approved, you can send to any email address

Best regards,
TaskSync Team`,
            html: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                    <h2>TaskSync Invitation Test</h2>
                    <p>Hello!</p>
                    <p>This is a test invitation email from TaskSync.</p>
                    
                    <div style="background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin: 20px 0;">
                        <h3>📋 Sandbox Mode Information</h3>
                        <p>Your account is currently in sandbox mode, which means:</p>
                        <ul>
                            <li>✅ You can only send emails to verified addresses</li>
                            <li>⏳ Production access request is under review (24 hours)</li>
                            <li>🚀 Once approved, you can send to any email address</li>
                        </ul>
                    </div>
                    
                    <p>Best regards,<br>TaskSync Team</p>
                </div>
            `
        };
        
        transporter.sendMail(testEmail, (error, info) => {
            if (error) {
                console.log('❌ Email sending failed:', error.message);
                console.log('\n🔍 Possible causes:');
                console.log('- Email address not verified in SES Console');
                console.log('- Invalid sender email');
                console.log('- Account still in sandbox mode');
                console.log('\n💡 Solution:');
                console.log('1. Go to AWS SES Console → Verified identities');
                console.log(`2. Add and verify: ${recipientEmail}`);
                console.log('3. Try again after verification');
            } else {
                console.log('✅ Email sent successfully!');
                console.log('Message ID:', info.messageId);
                console.log('\n🎉 AWS SES is working correctly in sandbox mode!');
                console.log('\n📋 Next Steps:');
                console.log('1. Wait for production access approval (24 hours)');
                console.log('2. Once approved, you can send to any email address');
                console.log('3. Update your Elastic Beanstalk environment variables');
            }
        });
    }
}); 