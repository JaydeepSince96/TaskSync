// Fix WhatsApp number format
require('dotenv').config();

console.log('🔧 Fixing WhatsApp Number Format...\n');

// Check current environment variables
console.log('📋 Current Environment Variables:');
console.log('  TWILIO_ACCOUNT_SID:', process.env.TWILIO_ACCOUNT_SID ? `${process.env.TWILIO_ACCOUNT_SID.substring(0, 10)}...` : 'Not set');
console.log('  TWILIO_AUTH_TOKEN:', process.env.TWILIO_AUTH_TOKEN ? `${process.env.TWILIO_AUTH_TOKEN.substring(0, 10)}...` : 'Not set');
console.log('  TWILIO_WHATSAPP_NUMBER:', process.env.TWILIO_WHATSAPP_NUMBER || 'Not set');

console.log('\n🔍 Issue Found:');
const currentNumber = process.env.TWILIO_WHATSAPP_NUMBER;
if (currentNumber && !currentNumber.startsWith('whatsapp:')) {
  console.log('❌ TWILIO_WHATSAPP_NUMBER is missing "whatsapp:" prefix');
  console.log('  Current:', currentNumber);
  console.log('  Should be: whatsapp:' + currentNumber);
  
  console.log('\n💡 Solution:');
  console.log('You need to update your environment variable TWILIO_WHATSAPP_NUMBER');
  console.log('from: ' + currentNumber);
  console.log('to:   whatsapp:' + currentNumber);
  
  console.log('\n📝 For local development, update your .env file:');
  console.log('TWILIO_WHATSAPP_NUMBER=whatsapp:' + currentNumber);
  
  console.log('\n📝 For production (Elastic Beanstalk), update environment variables:');
  console.log('TWILIO_WHATSAPP_NUMBER=whatsapp:' + currentNumber);
  
} else if (currentNumber && currentNumber.startsWith('whatsapp:')) {
  console.log('✅ TWILIO_WHATSAPP_NUMBER format is correct');
} else {
  console.log('❌ TWILIO_WHATSAPP_NUMBER is not set');
  console.log('💡 Set it to: whatsapp:+17817227094');
}

console.log('\n🎯 Next Steps:');
console.log('1. Update your environment variable TWILIO_WHATSAPP_NUMBER');
console.log('2. Add "whatsapp:" prefix to your phone number');
console.log('3. Restart your application');
console.log('4. Test again'); 