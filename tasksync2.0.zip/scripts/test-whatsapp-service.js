// Test WhatsApp service directly
require('dotenv').config();

console.log('🧪 Testing WhatsApp Service Directly...\n');

// Import the WhatsApp service
const { WhatsAppService } = require('../dist/services/whatsapp-service');

async function testWhatsAppService() {
  try {
    console.log('🔧 Creating WhatsApp service instance...');
    const whatsappService = new WhatsAppService();
    
    // Get service status
    const status = whatsappService.getStatus();
    console.log('📱 Service Status:', status);
    
    if (!status.available) {
      console.log('❌ WhatsApp service is not available');
      console.log('  - Initialized:', status.initialized);
      console.log('  - Has Credentials:', status.hasCredentials);
      console.log('  - From Number:', status.fromNumber);
      return;
    }
    
    console.log('✅ WhatsApp service is available');
    
    // Test with a phone number (you can change this)
    const testPhoneNumber = '+1234567890'; // Replace with your actual phone number
    console.log(`📞 Testing with phone number: ${testPhoneNumber}`);
    
    const result = await whatsappService.testConnection(testPhoneNumber);
    
    if (result) {
      console.log('✅ WhatsApp test message sent successfully!');
    } else {
      console.log('❌ WhatsApp test message failed to send');
    }
    
  } catch (error) {
    console.error('❌ Error testing WhatsApp service:', error);
  }
}

testWhatsAppService(); 