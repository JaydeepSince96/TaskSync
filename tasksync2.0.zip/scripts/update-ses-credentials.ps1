# PowerShell script to update AWS SES credentials
param(
    [Parameter(Mandatory=$true)]
    [string]$AccessKeyId,
    
    [Parameter(Mandatory=$true)]
    [string]$SecretAccessKey,
    
    [string]$FromEmail = "jaydeep.bhattachary@tasksync.org",
    
    [string]$Region = "ap-south-1"
)

Write-Host "🔧 Updating AWS SES Credentials..." -ForegroundColor Yellow

# Create .env file with updated credentials
$envContent = @"
# Server Configuration
PORT=3000
MONGO_URI=mongodb://localhost:27017/TaskSync

# JWT Configuration
JWT_SECRET=your-super-secret-jwt-key-change-this-in-production
JWT_REFRESH_SECRET=your-super-secret-refresh-key-change-this-in-production
JWT_EXPIRE=1h
JWT_REFRESH_EXPIRE=7d

# Google OAuth Configuration (Optional - leave empty to disable Google OAuth)
GOOGLE_CLIENT_ID=
GOOGLE_CLIENT_SECRET=

# Frontend URL for redirects
FRONTEND_URL=http://localhost:5173

# File Upload Configuration
UPLOAD_PATH=uploads/
MAX_FILE_SIZE=5000000

# Razorpay Configuration (Test Mode - Replace with live keys for production)
RAZORPAY_KEY_ID=rzp_test_ep5MhE2DpWyv8X
RAZORPAY_KEY_SECRET=UJItpRt6PxBiHR3ouoTjLPsX
RAZORPAY_WEBHOOK_SECRET=

# AWS SES Configuration (UPDATED)
AWS_SES_ACCESS_KEY_ID=$AccessKeyId
AWS_SES_SECRET_ACCESS_KEY=$SecretAccessKey
AWS_SES_REGION=$Region
AWS_SES_FROM_EMAIL=$FromEmail

# Twilio WhatsApp Configuration (Optional - for notifications)
TWILIO_ACCOUNT_SID=
TWILIO_AUTH_TOKEN=
TWILIO_WHATSAPP_NUMBER=

# OneSignal Push Notification Configuration (Optional)
ONESIGNAL_APP_ID=
ONESIGNAL_API_KEY=
"@

# Write to .env file
$envContent | Out-File -FilePath ".env" -Encoding UTF8

Write-Host "✅ .env file updated with new credentials!" -ForegroundColor Green

# Test the configuration
Write-Host "🧪 Testing new configuration..." -ForegroundColor Cyan
node scripts/test-email-service.js

Write-Host ""
Write-Host "📋 Next Steps:" -ForegroundColor Cyan
Write-Host "1. If test is successful, deploy to Elastic Beanstalk" -ForegroundColor White
Write-Host "2. Update your EB environment variables with the same credentials" -ForegroundColor White
Write-Host "3. Test invitation sending in production" -ForegroundColor White 