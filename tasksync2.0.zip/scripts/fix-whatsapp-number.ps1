# Fix WhatsApp Number Format
param(
    [string]$EnvironmentName = "tasksync-api"
)

Write-Host "🔧 Fixing WhatsApp Number Format..." -ForegroundColor Green
Write-Host ""

Write-Host "📋 Current Configuration:" -ForegroundColor Yellow
Write-Host "  Environment: $EnvironmentName" -ForegroundColor White
Write-Host ""

# Check if AWS CLI is configured
try {
    $account = aws sts get-caller-identity --query 'Account' --output text 2>$null
    if ($account) {
        Write-Host "✅ AWS CLI configured for account: $account" -ForegroundColor Green
    } else {
        Write-Host "❌ AWS CLI not configured. Please run 'aws configure' first." -ForegroundColor Red
        exit 1
    }
} catch {
    Write-Host "❌ AWS CLI not found or not configured." -ForegroundColor Red
    Write-Host "Please install and configure AWS CLI first." -ForegroundColor Yellow
    exit 1
}

Write-Host ""
Write-Host "🔧 Updating TWILIO_WHATSAPP_NUMBER format..." -ForegroundColor Yellow

# Create the option settings JSON
$optionSettings = @(
    @{
        Namespace = "aws:elasticbeanstalk:application:environment"
        OptionName = "TWILIO_WHATSAPP_NUMBER"
        Value = "whatsapp:+17817227094"
    }
)

$optionSettingsJson = $optionSettings | ConvertTo-Json -Depth 3

Write-Host "📝 New value: whatsapp:+17817227094" -ForegroundColor Cyan
Write-Host ""

try {
    Write-Host "🚀 Updating environment..." -ForegroundColor Yellow
    
    aws elasticbeanstalk update-environment `
        --environment-name $EnvironmentName `
        --option-settings $optionSettingsJson

    if ($LASTEXITCODE -eq 0) {
        Write-Host ""
        Write-Host "✅ Environment update initiated successfully!" -ForegroundColor Green
        Write-Host ""
        Write-Host "⏳ The environment will restart automatically." -ForegroundColor Yellow
        Write-Host "   This may take 2-3 minutes to complete." -ForegroundColor Yellow
        Write-Host ""
        Write-Host "🔍 You can monitor the status with:" -ForegroundColor Cyan
        Write-Host "   aws elasticbeanstalk describe-environments --environment-names $EnvironmentName" -ForegroundColor White
        Write-Host ""
        Write-Host "📱 After restart, try the WhatsApp test again!" -ForegroundColor Green
    } else {
        Write-Host "❌ Failed to update environment." -ForegroundColor Red
        exit 1
    }
} catch {
    Write-Host "❌ Error updating environment: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
} 