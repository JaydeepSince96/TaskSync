# 🚀 Deploy with Email Service Fix (PowerShell)
# This script deploys your application with proper email service configuration

param(
    [switch]$SkipEmailConfig
)

# Set error action preference
$ErrorActionPreference = "Stop"

Write-Host "🚀 Starting deployment with email service fix..." -ForegroundColor Blue

# Function to print colored output
function Write-Status {
    param([string]$Message)
    Write-Host "[INFO] $Message" -ForegroundColor Blue
}

function Write-Success {
    param([string]$Message)
    Write-Host "[SUCCESS] $Message" -ForegroundColor Green
}

function Write-Warning {
    param([string]$Message)
    Write-Host "[WARNING] $Message" -ForegroundColor Yellow
}

function Write-Error {
    param([string]$Message)
    Write-Host "[ERROR] $Message" -ForegroundColor Red
}

# Check if we're in the right directory
if (-not (Test-Path "package.json")) {
    Write-Error "Please run this script from the project root directory"
    exit 1
}

# Check if AWS CLI is installed
try {
    $null = Get-Command aws -ErrorAction Stop
} catch {
    Write-Error "AWS CLI is not installed. Please install it first."
    Write-Status "Installation guide: https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html"
    exit 1
}

# Check if EB CLI is installed
try {
    $null = Get-Command eb -ErrorAction Stop
} catch {
    Write-Error "EB CLI is not installed. Please install it first."
    Write-Status "Installation guide: https://docs.aws.amazon.com/elasticbeanstalk/latest/dg/eb-cli3-install.html"
    exit 1
}

Write-Status "Checking current environment..."

# Get current EB environment
try {
    $ebStatus = eb status --output json | ConvertFrom-Json
    $CURRENT_ENV = $ebStatus.EnvironmentName
    
    if (-not $CURRENT_ENV) {
        Write-Error "Could not determine current EB environment. Please run 'eb init' first."
        exit 1
    }
    
    Write-Success "Current environment: $CURRENT_ENV"
} catch {
    Write-Error "Failed to get EB environment status. Please run 'eb init' first."
    exit 1
}

# Build the application
Write-Status "Building application..."
try {
    npm run build
    Write-Success "Build completed successfully"
} catch {
    Write-Error "Build failed. Please fix the build errors first."
    exit 1
}

# Check email configuration
Write-Status "Checking email service configuration..."

# Create a temporary .ebextensions file for email configuration
if (-not (Test-Path ".ebextensions")) {
    New-Item -ItemType Directory -Path ".ebextensions" | Out-Null
}

$emailConfig = @"
option_settings:
  aws:elasticbeanstalk:application:environment:
    # Email Service Configuration
    # Uncomment and configure ONE of the following email providers:
    
    # Option 1: AWS SES (RECOMMENDED for AWS hosting)
    # AWS_SES_ACCESS_KEY_ID: your_aws_access_key_here
    # AWS_SES_SECRET_ACCESS_KEY: your_aws_secret_key_here
    # AWS_SES_REGION: ap-south-1
    # AWS_SES_FROM_EMAIL: your_verified_email@example.com
    
    # Option 2: SendGrid
    # SENDGRID_API_KEY: SG.your_sendgrid_api_key_here
    # SENDGRID_FROM_EMAIL: noreply@yourdomain.com
    # SENDGRID_FROM_NAME: TaskSync
    
    # Option 3: Mailgun
    # MAILGUN_API_KEY: key-your_mailgun_api_key_here
    # MAILGUN_DOMAIN: yourdomain.com
    # MAILGUN_FROM_EMAIL: noreply@yourdomain.com
    
    # Option 4: Legacy SMTP (Not recommended for production)
    # EMAIL_HOST: smtp.gmail.com
    # EMAIL_PORT: 587
    # EMAIL_SECURE: false
    # EMAIL_USER: your_email@gmail.com
    # EMAIL_PASS: your_app_password
    
    # Disable legacy SMTP to prevent authentication errors
    EMAIL_HOST: ""
    EMAIL_USER: ""
    EMAIL_PASS: ""
"@

$emailConfig | Out-File -FilePath ".ebextensions/01-email-config.config" -Encoding UTF8

if (-not $SkipEmailConfig) {
    Write-Warning "⚠️  IMPORTANT: Please configure your email service before deploying!"
    Write-Status "Edit .ebextensions/01-email-config.config and uncomment ONE email provider configuration"
    Write-Status "Then update the values with your actual credentials"
    Write-Host ""
    Write-Status "Recommended setup for AWS hosting:"
    Write-Status "1. Go to AWS SES Console and verify your email address"
    Write-Status "2. Create an IAM user with SES permissions"
    Write-Status "3. Uncomment AWS SES configuration in the file above"
    Write-Status "4. Add your actual AWS credentials"
    Write-Host ""
    
    $response = Read-Host "Have you configured the email service? (y/N)"
    if ($response -notmatch "^[Yy]$") {
        Write-Warning "Please configure email service first, then run this script again."
        Write-Status "See AWS_SES_SETUP_GUIDE.md for detailed instructions."
        exit 1
    }
}

# Deploy to Elastic Beanstalk
Write-Status "Deploying to Elastic Beanstalk..."
try {
    eb deploy
    Write-Success "Deployment completed successfully!"
} catch {
    Write-Error "Deployment failed!"
    exit 1
}

# Wait a moment for the deployment to settle
Write-Status "Waiting for deployment to settle..."
Start-Sleep -Seconds 30

# Test the health endpoint
Write-Status "Testing email service health..."

try {
    $ebStatus = eb status --output json | ConvertFrom-Json
    $HEALTH_URL = $ebStatus.CNAME
    
    if (-not $HEALTH_URL) {
        Write-Warning "Could not determine application URL. Please test manually."
    } else {
        Write-Status "Testing health endpoint: https://$HEALTH_URL/api/notifications/health"
        
        # Test health endpoint
        try {
            $HEALTH_RESPONSE = Invoke-RestMethod -Uri "https://$HEALTH_URL/api/notifications/health" -Method Get
            Write-Success "Health check successful!"
            $HEALTH_RESPONSE | ConvertTo-Json -Depth 10
        } catch {
            Write-Warning "Health check failed. Please test manually."
            Write-Status "Error: $($_.Exception.Message)"
        }
    }
} catch {
    Write-Warning "Could not test health endpoint. Please test manually."
}

# Clean up temporary files
if (Test-Path ".ebextensions") {
    Remove-Item -Path ".ebextensions" -Recurse -Force
}

Write-Success "🎉 Deployment completed!"
Write-Status "Next steps:"
Write-Status "1. Check your application logs for email service initialization"
Write-Status "2. Test sending an invitation email"
Write-Status "3. Monitor AWS SES console for email delivery statistics"
Write-Status "4. If using AWS SES, request production access to remove sandbox limitations"

Write-Host ""
Write-Status "Useful commands:"
Write-Status "  eb logs                    # View application logs"
Write-Status "  eb health                  # Check environment health"
Write-Status "  eb open                    # Open application in browser" 