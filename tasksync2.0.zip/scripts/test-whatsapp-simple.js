#!/usr/bin/env node

/**
 * Simple WhatsApp Test Script
 * 
 * This script tests the WhatsApp service without requiring compiled files
 * Run with: node scripts/test-whatsapp-simple.js
 */

require('dotenv').config();

console.log('📱 Simple WhatsApp Test');
console.log('========================');

// Check environment variables
console.log('\n📋 Environment Variables:');
console.log(`TWILIO_ACCOUNT_SID: ${process.env.TWILIO_ACCOUNT_SID ? '✅ Set' : '❌ Missing'}`);
console.log(`TWILIO_AUTH_TOKEN: ${process.env.TWILIO_AUTH_TOKEN ? '✅ Set' : '❌ Missing'}`);
console.log(`TWILIO_WHATSAPP_NUMBER: ${process.env.TWILIO_WHATSAPP_NUMBER || '❌ Missing'}`);

if (!process.env.TWILIO_ACCOUNT_SID || !process.env.TWILIO_AUTH_TOKEN) {
    console.log('\n❌ Missing required Twilio credentials!');
    console.log('Please add these to your .env file:');
    console.log('TWILIO_ACCOUNT_SID=your_account_sid');
    console.log('TWILIO_AUTH_TOKEN=your_auth_token');
    console.log('TWILIO_WHATSAPP_NUMBER=whatsapp:+14155238886');
    process.exit(1);
}

// Test Twilio client creation
try {
    const twilio = require('twilio');
    const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
    
    console.log('\n✅ Twilio client created successfully');
    console.log('📊 Account SID:', process.env.TWILIO_ACCOUNT_SID.substring(0, 10) + '...');
    console.log('🔑 Auth Token:', process.env.TWILIO_AUTH_TOKEN.substring(0, 10) + '...');
    console.log('📱 WhatsApp Number:', process.env.TWILIO_WHATSAPP_NUMBER || 'whatsapp:+14155238886');
    
    console.log('\n🎉 WhatsApp service is ready to use!');
    console.log('\n📋 Next Steps:');
    console.log('1. Add your Twilio credentials to .env file');
    console.log('2. Run: npm run build');
    console.log('3. Run: npm start');
    console.log('4. Test with: node scripts/test-whatsapp.js +1234567890');
    
} catch (error) {
    console.error('\n❌ Error creating Twilio client:', error.message);
    console.log('\n💡 Make sure you have:');
    console.log('- Valid Twilio Account SID');
    console.log('- Valid Twilio Auth Token');
    console.log('- Twilio package installed (npm install twilio)');
} 