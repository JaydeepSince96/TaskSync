// Comprehensive WhatsApp Fix Script
require('dotenv').config();

console.log('🔧 Comprehensive WhatsApp Fix Script\n');

// Check environment variables
console.log('📋 Environment Variables:');
console.log('  TWILIO_ACCOUNT_SID:', process.env.TWILIO_ACCOUNT_SID ? '✅ Set' : '❌ Not set');
console.log('  TWILIO_AUTH_TOKEN:', process.env.TWILIO_AUTH_TOKEN ? '✅ Set' : '❌ Not set');
console.log('  TWILIO_WHATSAPP_NUMBER:', process.env.TWILIO_WHATSAPP_NUMBER || '❌ Not set');

// Check if WhatsApp number has correct format
const whatsappNumber = process.env.TWILIO_WHATSAPP_NUMBER;
if (whatsappNumber && !whatsappNumber.startsWith('whatsapp:')) {
  console.log('\n🚨 ISSUE FOUND: WhatsApp number missing "whatsapp:" prefix');
  console.log('  Current:', whatsappNumber);
  console.log('  Should be: whatsapp:' + whatsappNumber);
  console.log('\n💡 SOLUTION: Update your environment variable');
  console.log('  TWILIO_WHATSAPP_NUMBER=whatsapp:' + whatsappNumber);
} else if (whatsappNumber && whatsappNumber.startsWith('whatsapp:')) {
  console.log('\n✅ WhatsApp number format is correct');
} else {
  console.log('\n❌ WhatsApp number is not set');
}

// Test Twilio client
console.log('\n🔧 Testing Twilio Client...');
try {
  const twilio = require('twilio');
  
  if (!process.env.TWILIO_ACCOUNT_SID || !process.env.TWILIO_AUTH_TOKEN) {
    console.log('❌ Missing Twilio credentials');
    process.exit(1);
  }
  
  const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
  console.log('✅ Twilio client created successfully');
  
  // Test account info
  client.api.accounts(process.env.TWILIO_ACCOUNT_SID)
    .fetch()
    .then(account => {
      console.log('✅ Twilio account verified:');
      console.log('  Account Name:', account.friendlyName);
      console.log('  Status:', account.status);
      console.log('  Type:', account.type);
      
      if (account.type === 'Trial') {
        console.log('\n📱 TWILIO SANDBOX SETUP REQUIRED:');
        console.log('Since you have a Trial account, you need to join the WhatsApp sandbox:');
        console.log('1. Send "join <your-sandbox-code>" to +14155238886');
        console.log('2. You\'ll receive a confirmation message');
        console.log('3. Then test with your phone number');
      }
    })
    .catch(error => {
      console.log('❌ Failed to verify Twilio account:', error.message);
    });
    
} catch (error) {
  console.log('❌ Error creating Twilio client:', error.message);
}

console.log('\n🎯 COMPLETE FIX CHECKLIST:');
console.log('1. ✅ Environment variables are set correctly');
console.log('2. ✅ WhatsApp number has "whatsapp:" prefix');
console.log('3. ✅ Twilio account is active');
console.log('4. 📱 Join Twilio sandbox (if using trial account)');
console.log('5. 🔄 Restart your application');
console.log('6. 🧪 Test with a real phone number');

console.log('\n📞 TESTING INSTRUCTIONS:');
console.log('1. Make sure your phone number is in international format (+1234567890)');
console.log('2. If using Twilio sandbox, join it first');
console.log('3. Test the WhatsApp connection from your frontend');
console.log('4. Check your WhatsApp for the test message'); 