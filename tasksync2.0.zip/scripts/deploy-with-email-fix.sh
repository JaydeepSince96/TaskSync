#!/bin/bash

# 🚀 Deploy with Email Service Fix
# This script deploys your application with proper email service configuration

set -e

echo "🚀 Starting deployment with email service fix..."

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    print_error "Please run this script from the project root directory"
    exit 1
fi

# Check if AWS CLI is installed
if ! command -v aws &> /dev/null; then
    print_error "AWS CLI is not installed. Please install it first."
    print_status "Installation guide: https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html"
    exit 1
fi

# Check if EB CLI is installed
if ! command -v eb &> /dev/null; then
    print_error "EB CLI is not installed. Please install it first."
    print_status "Installation guide: https://docs.aws.amazon.com/elasticbeanstalk/latest/dg/eb-cli3-install.html"
    exit 1
fi

print_status "Checking current environment..."

# Get current EB environment
CURRENT_ENV=$(eb status --output json | jq -r '.EnvironmentName')
if [ "$CURRENT_ENV" = "null" ] || [ -z "$CURRENT_ENV" ]; then
    print_error "Could not determine current EB environment. Please run 'eb init' first."
    exit 1
fi

print_success "Current environment: $CURRENT_ENV"

# Build the application
print_status "Building application..."
npm run build

if [ $? -ne 0 ]; then
    print_error "Build failed. Please fix the build errors first."
    exit 1
fi

print_success "Build completed successfully"

# Check email configuration
print_status "Checking email service configuration..."

# Create a temporary .ebextensions file for email configuration
mkdir -p .ebextensions

cat > .ebextensions/01-email-config.config << 'EOF'
option_settings:
  aws:elasticbeanstalk:application:environment:
    # Email Service Configuration
    # Uncomment and configure ONE of the following email providers:
    
    # Option 1: AWS SES (RECOMMENDED for AWS hosting)
    # AWS_SES_ACCESS_KEY_ID: your_aws_access_key_here
    # AWS_SES_SECRET_ACCESS_KEY: your_aws_secret_key_here
    # AWS_SES_REGION: ap-south-1
    # AWS_SES_FROM_EMAIL: your_verified_email@example.com
    
    # Option 2: SendGrid
    # SENDGRID_API_KEY: SG.your_sendgrid_api_key_here
    # SENDGRID_FROM_EMAIL: noreply@yourdomain.com
    # SENDGRID_FROM_NAME: TaskSync
    
    # Option 3: Mailgun
    # MAILGUN_API_KEY: key-your_mailgun_api_key_here
    # MAILGUN_DOMAIN: yourdomain.com
    # MAILGUN_FROM_EMAIL: noreply@yourdomain.com
    
    # Option 4: Legacy SMTP (Not recommended for production)
    # EMAIL_HOST: smtp.gmail.com
    # EMAIL_PORT: 587
    # EMAIL_SECURE: false
    # EMAIL_USER: your_email@gmail.com
    # EMAIL_PASS: your_app_password
    
    # Disable legacy SMTP to prevent authentication errors
    EMAIL_HOST: ""
    EMAIL_USER: ""
    EMAIL_PASS: ""
EOF

print_warning "⚠️  IMPORTANT: Please configure your email service before deploying!"
print_status "Edit .ebextensions/01-email-config.config and uncomment ONE email provider configuration"
print_status "Then update the values with your actual credentials"
echo ""
print_status "Recommended setup for AWS hosting:"
print_status "1. Go to AWS SES Console and verify your email address"
print_status "2. Create an IAM user with SES permissions"
print_status "3. Uncomment AWS SES configuration in the file above"
print_status "4. Add your actual AWS credentials"
echo ""

read -p "Have you configured the email service? (y/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    print_warning "Please configure email service first, then run this script again."
    print_status "See AWS_SES_SETUP_GUIDE.md for detailed instructions."
    exit 1
fi

# Deploy to Elastic Beanstalk
print_status "Deploying to Elastic Beanstalk..."
eb deploy

if [ $? -ne 0 ]; then
    print_error "Deployment failed!"
    exit 1
fi

print_success "Deployment completed successfully!"

# Wait a moment for the deployment to settle
print_status "Waiting for deployment to settle..."
sleep 30

# Test the health endpoint
print_status "Testing email service health..."

HEALTH_URL=$(eb status --output json | jq -r '.CNAME')
if [ "$HEALTH_URL" = "null" ] || [ -z "$HEALTH_URL" ]; then
    print_warning "Could not determine application URL. Please test manually."
else
    print_status "Testing health endpoint: https://$HEALTH_URL/api/notifications/health"
    
    # Test health endpoint
    HEALTH_RESPONSE=$(curl -s "https://$HEALTH_URL/api/notifications/health" || echo "FAILED")
    
    if [ "$HEALTH_RESPONSE" != "FAILED" ]; then
        print_success "Health check successful!"
        echo "$HEALTH_RESPONSE" | jq '.' 2>/dev/null || echo "$HEALTH_RESPONSE"
    else
        print_warning "Health check failed. Please test manually."
    fi
fi

# Clean up temporary files
rm -rf .ebextensions

print_success "🎉 Deployment completed!"
print_status "Next steps:"
print_status "1. Check your application logs for email service initialization"
print_status "2. Test sending an invitation email"
print_status "3. Monitor AWS SES console for email delivery statistics"
print_status "4. If using AWS SES, request production access to remove sandbox limitations"

echo ""
print_status "Useful commands:"
print_status "  eb logs                    # View application logs"
print_status "  eb health                  # Check environment health"
print_status "  eb open                    # Open application in browser" 